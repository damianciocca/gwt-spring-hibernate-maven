﻿============================================
    Procesamiento batch con Spring Batch    
                    http://www.dosideas.com
============================================

Ejemplos varios que demuestran el uso de Spring Batch para la creación y ejecución
de procesos batch. 

El proyecto consiste en varios ejemplos aislados, contenidos en paquetes "demo". 
Cada paquete contiene todas las clases, configuración y archivos necesarios para su 
ejecución, de manera de poder ver rapidamente los elementos involucrados. A si mismo,
cada paquete cuenta con un test JUnit que lo ejecuta, en donde también se explica el
comportamiento esperado.

Todos los archivos de configuración, clases y tests se encuentran documentados para 
explicar más en detalle su funcionamiento.

 Contenido
===========
 src/com/dosideas/springbatch/demoX      : paquete de la demo X. Cada paquete contiene todas
                                           las clases y archivos necesarios para esa demo.
 test/com/dosideas/springbatch/demoX     : test JUnit para ejecutar y comprobar la demoX.


 Preparación de la base de datos 
=================================
Algunas de las demo necesitan tablas en una base de datos para funcionar: 
 a) las tablas propias de Spring Batch   (schema-derby.sql)
 b) las tablas para la demo              (demo.sql)

Los scripts SQL necesarios se encuentran en el directorio "scripts-sql" en la
raiz del proyecto.

La demo está configurada para funcionar con una base de datos Derby, aunque
puede modificarse para funcionar con cualquier otra base. Derby es de simple
de usar y viene incorporada al IDE NetBeans 6.1

La demo del paquete "demo0" es la única que no utiliza una base de datos.


 Compilación y ejecución
=========================
 ant dist  : compilación del proyecto
 ant test  : ejecución de los tests
 
 Algunos test generan archivos como resultado de su ejecución. Dichos archivos quedan 
 generados en la raiz del proyecto (junto al build.xml).


 Más información
=================
http://www.dosideas.com/wiki/Spring_Framework